#!/bin/sh
# librespot subprocess sink: aplay child survives SIGKILL of this wrapper
# and exits cleanly on stdin EOF, so dmix releases its shared memory.
DIR=$(dirname "$0")
ALSA_DEVICE=default
[ -f "$DIR/librespot.conf" ] && . "$DIR/librespot.conf"

# Фоновым процессам sh по POSIX подставляет stdin=/dev/null, поэтому
# цепляем fd0 к явной копии stdin (это отменяет подстановку).
exec 3<&0
/usr/bin/aplay -q -D "$ALSA_DEVICE" -f S16_LE -c 2 -r 44100 -t raw <&3 &
echo $! > /var/run/spotify-sink.pid
wait
