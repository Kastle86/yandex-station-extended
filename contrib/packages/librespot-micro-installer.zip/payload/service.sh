#!/bin/sh
# Spotify Connect (librespot) — сервис для Yandex Station
# Управление: spotify {start|stop|restart|status|log}
DIR=/bkupgrade/data/local/opt/librespot
DAEMON=$DIR/librespot
CONF=$DIR/librespot.conf
PIDFILE=/var/run/spotify.pid
LOGFILE=$DIR/spotify.log
# аудио-кэш — в RAM (tmpfs), чтобы не занимать флеш; креды и громкость
# (system-кэш) обязаны переживать перезагрузку и лежат на /bkupgrade
CACHE=${CACHE:-/tmp/librespot-cache}
SYSTEM_CACHE=${SYSTEM_CACHE:-$DIR/system}
CACHE_LIMIT=16M

NAME='Yandex Station'
BITRATE=320
ALSA_DEVICE='default'
INITIAL_VOLUME=70
VOLUME_CTRL='linear'
VERBOSE=0

[ -f "$CONF" ] && . "$CONF"

is_running() {
    [ -f "$PIDFILE" ] || return 1
    pid=$(cat "$PIDFILE" 2>/dev/null)
    [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}

wait_net() {
    n=0
    while [ "$n" -lt 60 ]; do
        ip route 2>/dev/null | grep -q '^default' && return 0
        sleep 1
        n=$((n + 1))
    done
    return 1
}

# librespot держит aplay дочерним процессом. При остановке librespot
# aplay остаётся сиротой и продолжает занимать ALSA-устройство (dmix),
# из-за чего после restart нет звука. Убиваем такие «хвосты».
kill_sink() {
    sig=${1--TERM}
    for f in /proc/[0-9]*/cmdline; do
        [ -r "$f" ] || continue
        cmd=$(tr '\0' ' ' < "$f" 2>/dev/null)
        case "$cmd" in
            /usr/bin/aplay*"-D $ALSA_DEVICE"*) ;;
            *) continue ;;
        esac
        pid=${f#/proc/}
        pid=${pid%/cmdline}
        kill "$sig" "$pid" 2>/dev/null
    done
}

# После SIGKILL от librespot dmix иногда оставляет «мёртвый» SysV-сегмент
# (key 1024/1025), к которому цепляется новый aplay -> нет звука.
clean_shm() {
    command -v ipcrm >/dev/null 2>&1 || return 0
    [ -r /proc/sysvipc/shm ] || return 0
    awk 'NR > 1 && ($1 == 1024 || $1 == 1025) { print $2, $5, $7 }' /proc/sysvipc/shm |
    while read shmid cpid nattch; do
        [ "$nattch" = "0" ] || continue
        kill -0 "$cpid" 2>/dev/null && continue
        ipcrm -m "$shmid" 2>/dev/null
    done
}

start() {
    if is_running; then
        echo "spotify: уже запущен (PID $(cat "$PIDFILE"))"
        return 0
    fi
    [ -x "$DAEMON" ] || { echo "spotify: нет $DAEMON"; return 1; }
    kill_sink
    clean_shm
    # лог не должен расти бесконечно (debug-режим особенно)
    [ -f "$LOGFILE" ] && tail -n 3000 "$LOGFILE" > "$LOGFILE.tmp" && mv -f "$LOGFILE.tmp" "$LOGFILE"
    mkdir -p "$CACHE" "$SYSTEM_CACHE"
    (
        wait_net || echo "spotify: нет default-маршрута, стартую всё равно" >> "$LOGFILE"
        [ "$VERBOSE" = "1" ] && export RUST_LOG=librespot=debug
        # nohup: иначе SIGHUP при закрытии adb/ssh-сессии убивает демон
        exec nohup "$DAEMON" \
            --name "$NAME" \
            --backend subprocess \
            --device "$DIR/sink.sh" \
            --cache "$CACHE" \
            --system-cache "$SYSTEM_CACHE" \
            --cache-size-limit "$CACHE_LIMIT" \
            --bitrate "$BITRATE" \
            --initial-volume "$INITIAL_VOLUME" \
            --volume-ctrl "$VOLUME_CTRL"
    ) >> "$LOGFILE" 2>&1 < /dev/null &
    echo $! > "$PIDFILE"
    sleep 2
    if is_running; then
        echo "spotify: запущен (PID $(cat "$PIDFILE"))"
    else
        echo "spotify: не удалось запустить — смотри $LOGFILE"
        return 1
    fi
}

stop() {
    if is_running; then
        pid=$(cat "$PIDFILE")
        kill "$pid" 2>/dev/null
        sleep 1
        kill -9 "$pid" 2>/dev/null
    fi
    kill_sink
    sleep 1
    kill_sink -9
    killall librespot 2>/dev/null
    rm -f "$PIDFILE"
    echo "spotify: остановлен"
}

status() {
    if is_running; then
        echo "spotify: работает (PID $(cat "$PIDFILE"))"
        return 0
    fi
    echo "spotify: не запущен"
    return 1
}

restart() {
    stop
    sleep 1
    start
}

case "$1" in
    start|stop|restart|status) "$1" ;;
    log) tail -n 80 "$LOGFILE" ;;
    *) echo "Использование: spotify {start|stop|restart|status|log}"; exit 1 ;;
esac
