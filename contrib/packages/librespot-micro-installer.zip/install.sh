#!/bin/sh
# Fresh installation only. Run from the extracted distribution.
set -eu
cd "$(dirname "$0")"
MODE=${1:---check}
case "$MODE" in --check|--install) ;; *) echo 'Usage: sh install.sh [--check|--install]'; exit 2 ;; esac
fail() { echo "ERROR: $*" >&2; exit 1; }
[ "$(id -u)" = 0 ] || fail 'Root is required.'
for cmd in sha256sum mount cp mv chmod mkdir df awk tr grep readlink; do
    command -v "$cmd" >/dev/null 2>&1 || fail "Missing command: $cmd"
done
sha256sum -c SHA256SUMS || fail 'Archive integrity check failed.'
MODEL=$(tr -d '\000' < /proc/device-tree/model)
[ "$MODEL" = 'Yandex Station Micro v1.2' ] || fail "Unsupported model: $MODEL"
grep -q 'yandex,station-micro' /proc/device-tree/compatible || fail 'Unsupported device tree.'
[ "$(uname -r)" = 4.9.68 ] || fail 'This installer targets kernel 4.9.68 only.'
[ -x /usr/bin/aplay ] || fail 'System aplay is missing.'
[ -d /etc/init.d ] && [ -d /usr/local/bin ] || fail 'Unsupported system layout.'
grep -q 'ntp8910a-amplifier' /proc/asound/pcm || fail 'Unsupported audio device.'
DEST=/bkupgrade/data/local/opt/librespot
[ -d /bkupgrade/data ] || fail 'Persistent data partition is missing.'
[ ! -e "$DEST" ] && [ ! -L "$DEST" ] || fail 'Existing librespot installation: refusing to overwrite.'
for path in /etc/init.d/S99spotify /usr/local/bin/spotify /var/run/spotify.pid /var/run/spotify-sink.pid; do
    [ ! -e "$path" ] && [ ! -L "$path" ] || fail "Existing integration: $path"
done
if pidof librespot >/dev/null 2>&1; then fail 'librespot is already running.'; fi
[ ! -L /etc/asound.conf ] || fail 'Symlinked ALSA config needs manual review.'
[ -f /etc/asound.conf ] || fail 'Existing ALSA config is required for backup.'
FREE=$(df -k /bkupgrade | awk 'END {print $4}')
[ "$FREE" -ge 12288 ] || fail 'At least 12 MiB free space is required.'
echo 'Compatible hardware detected. Firmware/audio compatibility still needs playback verification.'
echo 'Will install librespot and boot entry; replace /etc/asound.conf with the tested Micro audio configuration.'
echo 'Existing ALSA configuration will be backed up. No credentials are included.'
[ "$MODE" = --install ] || exit 0

BACKUP=/bkupgrade/data/local/librespot-backup-$(date +%Y%m%d-%H%M%S)-$$
mkdir -p "$BACKUP"
cp -p /etc/asound.conf "$BACKUP/asound.conf"
ROOT_RO=0
awk '$2 == "/" {print $4}' /proc/mounts | grep -q '^ro\|,ro' && ROOT_RO=1
ROOT_TOUCHED=0
DEST_CREATED=0
COMMITTED=0
cleanup() {
    result=$?
    trap - EXIT HUP INT TERM
    if [ "$COMMITTED" = 0 ]; then
        if [ "$ROOT_TOUCHED" = 1 ]; then
            cp -p "$BACKUP/asound.conf" /etc/asound.conf || echo 'ERROR: restore ALSA config from backup!' >&2
            rm -f /etc/init.d/S99spotify /usr/local/bin/spotify
        fi
        if [ "$DEST_CREATED" = 1 ]; then
            rm -f "$DEST/librespot" "$DEST/service.sh" "$DEST/sink.sh" "$DEST/librespot.conf"
            rmdir "$DEST" 2>/dev/null || true
        fi
    fi
    sync
    if [ "$ROOT_RO" = 1 ] && [ "$ROOT_TOUCHED" = 1 ]; then
        mount -o remount,ro / || { echo 'ERROR: root remount ro failed; run mount -o remount,ro /' >&2; result=1; }
    fi
    exit "$result"
}
trap cleanup EXIT
trap 'exit 1' HUP INT TERM
mkdir -p "$(dirname "$DEST")"
mkdir "$DEST"
DEST_CREATED=1
cp payload/librespot payload/service.sh payload/sink.sh payload/librespot.conf "$DEST/"
chmod 755 "$DEST/librespot" "$DEST/service.sh" "$DEST/sink.sh"
chmod 600 "$DEST/librespot.conf"
"$DEST/librespot" --version
if [ "$ROOT_RO" = 1 ]; then mount -o remount,rw /; fi
ROOT_TOUCHED=1
cp payload/asound.conf /etc/asound.conf
cp payload/S99spotify /etc/init.d/S99spotify
cp payload/spotify /usr/local/bin/spotify
chmod 644 /etc/asound.conf
chmod 755 /etc/init.d/S99spotify /usr/local/bin/spotify
sync
COMMITTED=1
echo "Installed. Original ALSA configuration: $BACKUP/asound.conf"
echo 'Start when ready: spotify start'
echo 'Then select Yandex Station in Spotify Connect on the same network.'
echo 'Boot startup is enabled. Playback has not been tested by this installer.'
